package edu.upenn.mkse212.hw2.web.client;

import java.util.Set;

import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * The client side stub for the RPC service.
 */
public interface ImageServiceAsync {
	void fetchImageResults(String name, AsyncCallback<Set<String>> callback);
}
